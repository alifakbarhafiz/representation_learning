"""Utilities: timing, metrics, visualization."""

